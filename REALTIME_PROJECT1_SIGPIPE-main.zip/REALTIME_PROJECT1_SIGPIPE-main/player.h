#ifndef __PLAYER_H_
#define __PLAYER_H_

struct PLAYER{
    int number;
    int energy;
    int teamnum;
} player;

#endif