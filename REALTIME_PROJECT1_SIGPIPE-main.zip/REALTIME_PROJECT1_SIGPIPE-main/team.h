#ifndef __TEAM_H_
#define __TEAM_H_

#include "header.h"


struct TEAM{
    int teamnumber;
    int number_of_players;
    int teamlead_energy;
    int num_of_balls;
} team;


void recv_ball(int ball_sig);
void send_info(int end_rd_sig);

#endif