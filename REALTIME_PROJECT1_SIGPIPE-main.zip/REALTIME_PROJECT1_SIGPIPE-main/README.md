# REALTIME_PROJECT1_SIGPIPE
Real time project - Signals and Pipes under linux
